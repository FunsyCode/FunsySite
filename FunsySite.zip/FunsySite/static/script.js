document.getElementById('toggleButton').addEventListener('click', function() {
    if (window.location.pathname.endsWith('index.html')) {
        window.location.href = 'page2.html'; // Перейти на другую страницу
    } else {
        window.location.href = 'index.html'; // Вернуться обратно
    }
});
