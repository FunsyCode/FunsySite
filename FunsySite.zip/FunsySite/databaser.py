from datetime import datetime
from random import randbytes
import sqlite3

class Database:
    def __init__(self, db_file = 'databaser.db'):
        self.connection = sqlite3.connect(db_file)
        self.cursor = self.connection.cursor()

        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Users (
                id CHAR(16) PRIMARY KEY,
                username TINYTEXT NOT NULL UNIQUE,
                password TINYTEXT NOT NULL,
                email TINYTEXT NOT NULL UNIQUE,
                datetime DATETIME NOT NULL
            )''')

        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Files (
                id CHAR(16) PRIMARY KEY,
                filename TINYTEXT NOT NULL UNIQUE,
                password TINYTEXT
            )''')

        self.connection.commit()

    def add_user(self, username, password, email):
        try:
            self.cursor.execute('INSERT INTO Users (id, username, password, email, datetime) VALUES (?, ?, ?, ?, ?)', (randbytes(8).hex(), username, password, email, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            self.connection.commit()

        except sqlite3.IntegrityError:
            return False
        
        return True
    
    def get_user(self, username, password):
        self.cursor.execute('SELECT * FROM Users WHERE username = ? AND password = ?', (username, password))

        return self.cursor.fetchone() is not None

    def add_file(self, filename, password = 'NULL'):
        try:
            self.cursor.execute('INSERT INTO Files (id, filename, password) VALUES (?, ?, ?)', (randbytes(8).hex(), filename, password))
            self.connection.commit()

        except sqlite3.IntegrityError:    
            return False
        
        return True
    
    def get_file(self, filename, password = 'NULL'):
        self.cursor.execute('SELECT * FROM Files WHERE filename = ? AND password = ?', (filename, password))
        
        return self.cursor.fetchone() is not None